[jQuery Auto Complete](http://www.codenothing.com/archives/jquery/auto-complete/)
========================

Autocomplete enbles custom hinting on input fields. Both client and server side matching is supported.


Bowser Support
--------------

**IE** 6, 7, 8  
**FireFox** 2.0.0.20, 3.0.17, 3.5.7, 3.6  
**Safari** 3.0.4, 3.1.2, 3.2.1, 4.0.5  
**Opera** 9.52, 9.64, 10.01, 10.10  
**Chrome** 5.0  

Credits
--------
[Corey Hart](http://www.codenothing.com) - Creator
